<?php
// Buscador de bienes raíces: compatible con PHP 7.0+
$archivo = __DIR__ . '/data-1.json';
if (!is_file($archivo) || !is_readable($archivo)) {
    http_response_code(500);
    die('No se encontró data-1.json. Verifica que esté junto a index.php.');
}
$contenido = file_get_contents($archivo);
$propiedades = json_decode($contenido, true);
if (!is_array($propiedades)) {
    http_response_code(500);
    die('No se pudieron leer los datos JSON. Verifica el archivo data-1.json.');
}

function precioNumero($precio) {
    return (int) preg_replace('/[^0-9]/', '', (string)$precio);
}
function h($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

$ciudades = array();
$tipos = array();
$precios = array();
foreach ($propiedades as $p) {
    if (isset($p['Ciudad'])) $ciudades[] = $p['Ciudad'];
    if (isset($p['Tipo'])) $tipos[] = $p['Tipo'];
    if (isset($p['Precio'])) $precios[] = precioNumero($p['Precio']);
}
$ciudades = array_values(array_unique($ciudades));
$tipos = array_values(array_unique($tipos));
 sort($ciudades, SORT_NATURAL | SORT_FLAG_CASE);
 sort($tipos, SORT_NATURAL | SORT_FLAG_CASE);
$minDatos = count($precios) ? min($precios) : 0;
$maxDatos = count($precios) ? max($precios) : 0;

$ciudad = isset($_POST['ciudad']) ? trim($_POST['ciudad']) : '';
$tipo = isset($_POST['tipo']) ? trim($_POST['tipo']) : '';
$mostrarTodos = isset($_POST['mostrar_todos']);
$minPrecio = isset($_POST['min_precio']) && $_POST['min_precio'] !== '' ? (int)$_POST['min_precio'] : $minDatos;
$maxPrecio = isset($_POST['max_precio']) && $_POST['max_precio'] !== '' ? (int)$_POST['max_precio'] : $maxDatos;
if ($minPrecio > $maxPrecio) {
    $temporal = $minPrecio;
    $minPrecio = $maxPrecio;
    $maxPrecio = $temporal;
}
$minPrecio = max($minDatos, min($minPrecio, $maxDatos));
$maxPrecio = max($minDatos, min($maxPrecio, $maxDatos));

$resultados = array();
foreach ($propiedades as $p) {
    if ($mostrarTodos) {
        $resultados[] = $p;
        continue;
    }
    $precio = isset($p['Precio']) ? precioNumero($p['Precio']) : 0;
    $coincideCiudad = ($ciudad === '' || (isset($p['Ciudad']) && $p['Ciudad'] === $ciudad));
    $coincideTipo = ($tipo === '' || (isset($p['Tipo']) && $p['Tipo'] === $tipo));
    $coincidePrecio = ($precio >= $minPrecio && $precio <= $maxPrecio);
    if ($coincideCiudad && $coincideTipo && $coincidePrecio) $resultados[] = $p;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Buscador de bienes raíces</title>
  <link rel="stylesheet" href="css/materialize.min.css">
  <link rel="stylesheet" href="css/customColors.css">
  <link rel="stylesheet" href="css/index.css">
  <style>
    body{background:#e9eeeb;font-family:Arial,sans-serif}
    .contenedor{background:rgba(242,242,242,.94);align-items:stretch}
    .colFiltros{height:auto;min-height:570px;padding:0 0 22px}
    .colFiltros form,.filtrosContenido{height:auto;min-height:570px}
    .filtrosContenido{display:flex;flex-direction:column;align-content:stretch;gap:12px;padding-bottom:20px}
    .tituloFiltros{height:auto;min-height:90px;padding:10px}
    .tituloFiltros h5{margin:12px 0}
    .filtroCiudad,.filtroTipo{height:auto;min-height:88px;padding:8px 16px;text-align:left}
    .filtroCiudad label,.filtroTipo label,.filtroPrecio label{display:block;position:static!important;transform:none!important;color:#333;font-size:1rem;margin:0 0 8px}
    .filtroCiudad select,.filtroTipo select{display:block!important;visibility:visible!important;opacity:1!important;position:static!important;width:100%;height:42px;padding:0 10px;border:1px solid #aaa;border-radius:3px;background:#fff;color:#222;box-sizing:border-box}
    .filtroPrecio{width:auto;height:auto;margin:8px 16px;padding:0}
    .campos-precio{display:flex;gap:10px;margin-top:8px}
    .campo-precio{flex:1;min-width:0}
    .campo-precio label{font-size:.85rem!important;margin-bottom:4px}
    .campo-precio input{width:100%!important;height:40px!important;margin:0!important;padding:0 8px!important;box-sizing:border-box!important;border:1px solid #aaa!important;border-radius:3px!important;background:#fff!important}
    .ayuda-precio{display:block;margin-top:7px;color:#555;font-size:.78rem;line-height:1.4}
    .botonField{height:auto;padding:8px;text-align:center}
    .botonField button{margin:4px}
    .colContenido{align-content:flex-start;gap:12px}
    .tituloContenido{min-height:155px}
    .itemMostrado{background:#fff;padding:16px;border-radius:3px;box-shadow:0 2px 5px #0002;width:100%;margin-top:0}
    .datos-propiedad{padding:5px 18px;flex:1}
    .datos-propiedad p{margin:7px 0}
    .precioTexto{font-weight:bold}
    .sin-resultados{background:#fff;padding:25px;width:100%;text-align:center}
    @media(max-width:760px){.contenedor{width:96%;margin:12px auto}.colFiltros,.colContenido{width:100%;min-height:0}.colFiltros form,.filtrosContenido{min-height:0}.colContenido{padding:12px}.tituloContenido h5{font-size:1.4rem}}
  </style>
</head>
<body>
<div class="contenedor">
  <div class="card rowTitulo"><h1>Buscador de bienes raíces</h1></div>
  <aside class="colFiltros">
    <form action="index.php" method="post" id="formulario">
      <div class="filtrosContenido">
        <div class="tituloFiltros"><h5>Realiza una búsqueda personalizada</h5></div>
        <div class="filtroCiudad">
          <label for="selectCiudad">Ciudad:</label>
          <select name="ciudad" id="selectCiudad">
            <option value="">Todas las ciudades</option>
            <?php foreach ($ciudades as $c): ?>
              <option value="<?=h($c)?>" <?=($ciudad === $c ? 'selected' : '')?>><?=h($c)?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="filtroTipo">
          <label for="selectTipo">Tipo de vivienda:</label>
          <select name="tipo" id="selectTipo">
            <option value="">Todos los tipos</option>
            <?php foreach ($tipos as $t): ?>
              <option value="<?=h($t)?>" <?=($tipo === $t ? 'selected' : '')?>><?=h($t)?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="filtroPrecio">
          <label>Rango de precios:</label>
          <div class="campos-precio">
            <div class="campo-precio">
              <label for="minPrecio">Precio mínimo ($)</label>
              <input type="number" id="minPrecio" name="min_precio" min="<?=$minDatos?>" max="<?=$maxDatos?>" value="<?=$mostrarTodos ? $minDatos : $minPrecio?>" required>
            </div>
            <div class="campo-precio">
              <label for="maxPrecio">Precio máximo ($)</label>
              <input type="number" id="maxPrecio" name="max_precio" min="<?=$minDatos?>" max="<?=$maxDatos?>" value="<?=$mostrarTodos ? $maxDatos : $maxPrecio?>" required>
            </div>
          </div>
          <small class="ayuda-precio">Valores disponibles: $<?=number_format($minDatos)?> a $<?=number_format($maxDatos)?>.</small>
        </div>
        <div class="botonField">
          <button type="submit" class="btn" id="submitButton">Buscar</button>
          <a href="index.php" class="btn white" style="color:#648C7D">Limpiar</a>
        </div>
      </div>
    </form>
  </aside>
  <main class="colContenido">
    <section class="tituloContenido card">
      <h5>Resultados de la búsqueda</h5><div class="divider"></div>
      <p>Se encontraron <strong><?=count($resultados)?></strong> de <?=count($propiedades)?> propiedades.</p>
      <form action="index.php" method="post">
        <button type="submit" name="mostrar_todos" value="1" class="btn-flat waves-effect" id="mostrarTodos">Mostrar todos</button>
      </form>
    </section>
    <?php if (!$resultados): ?>
      <div class="sin-resultados">No se encontraron propiedades con esos filtros. Prueba con otro rango de precios o cambia los filtros.</div>
    <?php else: foreach ($resultados as $p): ?>
      <article class="itemMostrado">
        <div class="datos-propiedad">
          <h5><?=h(isset($p['Tipo']) ? $p['Tipo'] : '')?></h5>
          <p class="precioTexto"><?=h(isset($p['Precio']) ? $p['Precio'] : '')?></p>
          <p><strong>Dirección:</strong> <?=h(isset($p['Direccion']) ? $p['Direccion'] : '')?></p>
          <p><strong>Ciudad:</strong> <?=h(isset($p['Ciudad']) ? $p['Ciudad'] : '')?></p>
          <p><strong>Código postal:</strong> <?=h(isset($p['Codigo_Postal']) ? $p['Codigo_Postal'] : '')?></p>
          <p><strong>Teléfono:</strong> <?=h(isset($p['Telefono']) ? $p['Telefono'] : '')?></p>
          <p><strong>ID:</strong> <?=h(isset($p['Id']) ? $p['Id'] : '')?></p>
        </div>
      </article>
    <?php endforeach; endif; ?>
  </main>
</div>
</body>
</html>
